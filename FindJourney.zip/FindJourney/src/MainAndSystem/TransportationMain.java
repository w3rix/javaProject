package MainAndSystem;
import GUI.TransportationGUI;

public class TransportationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TransportationGUI tg = new TransportationGUI();
		tg.setVisible(true);

	}

}
