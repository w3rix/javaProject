package Interface;

public interface Discountable {
	
	 double calculateDiscount(double baseRate, double discountRate);

}
